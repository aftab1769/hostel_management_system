<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div class="container-scroller">
        <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container-fluid page-body-wrapper">
            <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-panel">
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('template/vendors/js/vendor.bundle.base.js')); ?>"></script>
    <script src="<?php echo e(asset('template/vendors/chart.js/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/vendors/progressbar.js/progressbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/vendors/jvectormap/jquery-jvectormap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/vendors/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <script src="<?php echo e(asset('template/vendors/owl-carousel-2/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/hoverable-collapse.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/misc.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/settings.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/todolist.js')); ?>"></script>
    <script src="<?php echo e(asset('template/js/dashboard.js')); ?>"></script>
</body>

</html>
<?php /**PATH C:\Users\ar\Desktop\hostel_management_system\resources\views/layout/main.blade.php ENDPATH**/ ?>