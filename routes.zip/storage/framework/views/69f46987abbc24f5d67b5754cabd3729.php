

<?php $__env->startSection('title', 'Dashboard'); ?>

<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<?php $__env->startSection('content'); ?>
    <div class="content-wrapper" style="padding: 50px">
        <div class="row mb-3">
            <div class="col-6">
                <h3>Rooms</h3>
            </div>
            <div class="col-6">
                <button style="float: right" type="button" class="btn btn-primary" data-bs-toggle="modal"
                    data-bs-target="#addModal" onclick="clearAddModal()">
                    Add Room
                </button>
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div id="alert"></div>
                <div id="response"></div>
                <div class="table-responsive">
                    
                    
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('partials.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        const ID = <?php echo json_encode(Auth::id(), 15, 512) ?>;
        const showAllRoute = <?php echo json_encode(route('api.admin.rooms', Auth::id()), 512) ?>;
        const addRoute = <?php echo json_encode(route('api.admin.room.create'), 15, 512) ?>;
        const showSingleRoute = <?php echo json_encode(route('api.admin.room.show', ':id'), 512) ?>;
        const updateRoute = <?php echo json_encode(route('api.admin.room.update', ':id'), 512) ?>;
        const destroyRoute = <?php echo json_encode(route('api.admin.room.destroy', ':id'), 512) ?>;

    </script>

    <script src="<?php echo e(asset('template/jscustom/custom.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ar\Desktop\hostel_management_system\resources\views/admin/room/index.blade.php ENDPATH**/ ?>