<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link rel="stylesheet" href="<?php echo e(asset('template/vendors/mdi/css/materialdesignicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/vendors/css/vendor.bundle.base.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('template/vendors/jvectormap/jquery-jvectormap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/vendors/owl-carousel-2/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('template/vendors/owl-carousel-2/owl.theme.default.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('template/css/style.css')); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset('template/images/favicon.png')); ?>" />

    
</head>
<?php /**PATH C:\Users\ar\Desktop\hostel_management_system\resources\views/partials/head.blade.php ENDPATH**/ ?>