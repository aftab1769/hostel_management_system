<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper" style="padding: 50px">
        <div class="row mb-3">
            <div class="col-6">
                <h3>Students</h3>
            </div>
            <div class="col-6">
                <a style="float: right" class="btn btn-primary" href="<?php echo e(route('admin.student.create')); ?>">Add Student</a>
            </div>
        </div>
        <div class="card">
            <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(count($students) !== 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Picture</th>
                            <th>Name</th>
                            <th>CNIC</th>
                            <th>Room No.</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <?php if(empty($student->picture)): ?>
                                        <img src="https://ui-avatars.com/api/?name=<?php echo e($student->name); ?>"
                                            class="img-xs rounded-circle" alt="<?php echo e($student->name); ?>" />
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('template/std_img/' . $student->picture)); ?>"
                                            class="img-xs rounded-circle" alt="<?php echo e($student->name); ?>" />
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($student->name); ?></td>
                                <td><?php echo e($student->cnic); ?></td>
                                <td><?php echo e($student->room_no); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.student.show', $student)); ?>" class="btn btn-secondary">Show</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-success">No Record Found!</div>
            <?php endif; ?>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ar\Desktop\hostel_management_system\resources\views/admin/student/index.blade.php ENDPATH**/ ?>