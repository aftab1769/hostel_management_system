<footer class="footer">
    <div class="text-center">
        Copyright ©  Hostelmanagement 2024
    </div>
</footer><?php /**PATH C:\Users\ar\Desktop\hostel_management_system\resources\views/partials/footer.blade.php ENDPATH**/ ?>