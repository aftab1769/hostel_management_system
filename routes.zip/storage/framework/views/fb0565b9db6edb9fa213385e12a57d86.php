

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row mb-4 mt-3">
            <div class="col-md-6">
                <h3>Menu</h3>
            </div>
            <div class="col-md-6">
                <a href="<?php echo e(route('admin.menu.create')); ?>" class="btn btn-primary" style="float: right">Add Menu</a>
            </div>
        </div>
        <div class="card">
            <?php echo $__env->make('partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php if(count($menus) !== 0): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Sr No.</th>
                            <th>Days</th>
                            <th>Breakfast</th>
                            <th>Lunch</th>
                            <th>Dinner</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($menu->day); ?></td>
                                <td><?php echo e($menu->breakfast); ?></td>
                                <td><?php echo e($menu->lunch); ?></td>
                                <td><?php echo e($menu->dinner); ?></td>
                                <td>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <a href="<?php echo e(route('admin.menu.edit', $menu)); ?>" class="btn btn-warning mr-3"><i class="mdi mdi-pencil"> </i></a>
                                        </div>
                                        <div class="col-md-3">
                                            <form action="<?php echo e(route('admin.menu.destroy', $menu)); ?>" method="post">
                                                <?php echo method_field('DELETE'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button class="btn btn-danger"><i class="mdi mdi-delete"></i></button>
                                            </form>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="alert alert-success">No Record Found!</div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ar\Desktop\hostel_management_system\resources\views/admin/menu/index.blade.php ENDPATH**/ ?>