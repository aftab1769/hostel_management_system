<!DOCTYPE html>
<html>

<head>
    <!-- Basic -->
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <!-- Site Metas -->
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <title>Dashboard</title>

    <!-- slider stylesheet -->
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
    <!-- bootstrap core css -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/bootstrap.css') }}" />
    <!-- font awesome style -->
    <link rel="stylesheet" type="text/css" href="{{ asset('assets/css/font-awesome.min.css') }}" />

    <!-- Custom styles for this template -->
    <link href="{{ asset('assets/css/style.css') }}" rel="stylesheet" />
    <!-- responsive style -->
    <link href="{{ asset('assets/css/responsive.css') }}" rel="stylesheet" />

</head>

<body>
    <div class="hero_area">
        <!-- header section strats -->
        <header class="header_section">
            <div class="header_top">
                <div class="container-fluid">
                    <div class="contact_nav">
                        <a href="">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                            <span>
                                Call : +01 123455678990
                            </span>
                        </a>
                        <a href="">
                            <span>
                                Your CNIC:  {{ Auth::user()->cnic }}
                            </span>
                        </a>
                    </div>
                </div>
            </div>
            <div class="header_bottom">
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-lg custom_nav-container ">
                        <a class="navbar-brand" href="{{ route('user.dashboard') }}">
                            <span>
                                Hostel Management System
                            </span>
                        </a>

                        <button class="navbar-toggler" type="button" data-toggle="collapse"
                            data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                            aria-expanded="false" aria-label="Toggle navigation">
                            <span class=""> </span>
                        </button>

                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <ul class="navbar-nav ">
                                <li class="nav-item active">
                                    <a class="nav-link" href="{{ route('user.dashboard') }}">Home <span
                                            class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('user.dashboard.about') }}"> About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('user.dashboard.service') }}">Services</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('user.dashboard.contact') }}">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </header>
        <!-- end header section -->
        <!-- slider section -->
        <section class="slider_section mb-5"
            style="background-image: url({{ asset('assets/images/pexels-mrwson-4275890.jpg') }}); background-size: cover;">
            <div class="container">
                <div class="row">
                    <div class="detail-box">
                        <h1 class="mt-4 text-white">
                            SaQii Boys Hostel <br>Rawalpindi
                        </h1>
                        <p style="color: white;">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui harum voluptatem adipisci. Quos
                            molestiae
                            saepe dicta nobis pariatur, tempora iusto, ad possimus soluta hic praesentium mollitia
                            consequatur beatae,
                            aspernatur culpa.
                        </p>
                        <a href="">
                            Contact Us
                        </a>
                    </div>
                </div>
            </div>
        </section>
        <!-- end slider section -->
    </div>

    <!-- feature section -->
    <div class="container mt-4 mb-5">
        <h2>Our Rooms</h2>
        <div class="row mb-3">
            <div class="col-md-4">
                <img src="{{ asset('assets/images/room1.jpg') }}" alt="" style="border-radius: 50%" width="300px" height="300px">
            </div>
            <div class="col-md-4">
                <img src="{{ asset('assets/images/room2.jpg') }}" alt="" style="border-radius: 50%" width="300px" height="300px">
            </div>
            <div class="col-md-4">
                <img src="{{ asset('assets/images/room3.jpg') }}" alt="" style="border-radius: 50%" width="300px" height="300px">
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-4">
                <img src="{{ asset('assets/images/room1.jpg') }}" alt="" style="border-radius: 50%" width="300px" height="300px">
            </div>
            <div class="col-md-4">
                <img src="{{ asset('assets/images/room2.jpg') }}" alt="" style="border-radius: 50%" width="300px" height="300px">
            </div>
            <div class="col-md-4">
                <img src="{{ asset('assets/images/room3.jpg') }}" alt="" style="border-radius: 50%" width="300px" height="300px">
            </div>
        </div>
        <a href="{{ route('user.student') }}" class="btn btn-warning ml-2 p-3 mt-4">Book Room</a>
    </div>

    <!-- end feature section -->

    <!-- about section -->

    <section class="about_section layout_padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-5 col-md-6">
                    <div class="detail-box">
                        <h2>
                            About us
                        </h2>
                        <p>
                            There are many variations of passages of Lorem Ipsum available, but the majority have
                            suffered alteration
                            in some form, by injected humour, or randomisedThere are many variations of passages of
                            Lorem Ipsum
                            available, but the majority have suffered alteration in some form, by injected humour, or
                            randomised
                        </p>
                        <a href="">
                            Read More
                        </a>
                    </div>
                </div>
                <div class="col-lg-7 col-md-6">
                    <div class="img-box">
                        <img src="{{ asset('assets/images/pexels-george-pak-7968277.jpg') }}" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end about section -->


    <!-- professional section -->

    <section class="professional_section layout_padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="img-box">
                        <img src="{{ asset('assets/images/professional-img.png') }}" alt="">
                    </div>
                </div>
                <div class="col-md-6 ">
                    <div class="detail-box">
                        <h2>
                            We Provide Home <br>
                            Environment
                        </h2>
                        <p>
                            randomised words which don't look even slightly believable. If you are going to use a
                            passage of Lorem
                            Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.
                            All randomised
                            words which don't look even slightly
                        </p>
                        <a href="">
                            Read More
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end professional section -->

    <!-- service section -->

    <section class="service_section layout_padding">
        <div class="container ">
            <div class="heading_container heading_center">
                <h2> Our Services </h2>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-4 mx-auto">
                    <div class="box ">
                        <div class="img-box">
                            <img src="images/s1.png" alt="" />
                        </div>
                        <div class="detail-box">
                            <h5>
                                Luandry
                            </h5>
                            <p>
                                when looking at its layout. The point of using Lorem Ipsum is
                                that it has a more-or-less normal
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 mx-auto">
                    <div class="box ">
                        <div class="img-box">
                            <img src="images/s2.png" alt="" />
                        </div>
                        <div class="detail-box">
                            <h5>
                                Security
                            </h5>
                            <p>
                                when looking at its layout. The point of using Lorem Ipsum is
                                that it has a more-or-less normal
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-4 mx-auto">
                    <div class="box ">
                        <div class="img-box">
                            <img src="images/s3.png" alt="" />
                        </div>
                        <div class="detail-box">
                            <h5>
                                Parking
                            </h5>
                            <p>
                                when looking at its layout. The point of using Lorem Ipsum is
                                that it has a more-or-less normal
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="btn-box">
                <a href="">
                    View More
                </a>
            </div>
        </div>
    </section>

    <!-- end service section -->

    <!-- client section -->

    <section class="client_section ">
        <div class="container">
            <div class="heading_container heading_center">
                <h2>
                    What Our Students Say
                </h2>
            </div>
            <div class="carousel-wrap layout_padding2-top ">
                <div class="owl-carousel">
                    <div class="item">
                        <div class="box">
                            <div class="client_id">
                                <div class="img-box">
                                    <img src="images/client-1.jpg" alt="">
                                </div>
                                <div class="client_detail">
                                    <div class="client_info">
                                        <h6>
                                            Mehr Ali                                        </h6>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="client_text">
                                <p>
                                    chunks as necessary, making this the first true generator on the Internet. It uses a
                                    dictionary of
                                    over 200 Latin words, combined with a handful of model sentence structures, to
                                    generate Lorem Ipsum
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="box">
                            <div class="client_id">
                                <div class="img-box">
                                    <img src="images/client-2.jpg" alt="">
                                </div>
                                <div class="client_detail">
                                    <div class="client_info">
                                        <h6>
                                            Jorch morik
                                        </h6>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="client_text">
                                <p>
                                    chunks as necessary, making this the first true generator on the Internet. It uses a
                                    dictionary of
                                    over 200 Latin words, combined with a handful of model sentence structures, to
                                    generate Lorem Ipsum
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="box">
                            <div class="client_id">
                                <div class="img-box">
                                    <img src="images/client-1.jpg" alt="">
                                </div>
                                <div class="client_detail">
                                    <div class="client_info">
                                        <h6>
                                            Jorch morik
                                        </h6>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="client_text">
                                <p>
                                    chunks as necessary, making this the first true generator on the Internet. It uses a
                                    dictionary of
                                    over 200 Latin words, combined with a handful of model sentence structures, to
                                    generate Lorem Ipsum
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="item">
                        <div class="box">
                            <div class="client_id">
                                <div class="img-box">
                                    <img src="images/client-2.jpg" alt="">
                                </div>
                                <div class="client_detail">
                                    <div class="client_info">
                                        <h6>
                                            Jorch morik
                                        </h6>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <i class="fa fa-quote-left" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="client_text">
                                <p>
                                    chunks as necessary, making this the first true generator on the Internet. It uses a
                                    dictionary of
                                    over 200 Latin words, combined with a handful of model sentence structures, to
                                    generate Lorem Ipsum
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end client section -->

    <!-- contact section -->

    <section class="contact_section layout_padding">
        <div class="container">
            <div class="heading_container">
                <h2>
                    Contact Us
                </h2>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <form action="">
                        <div>
                            <input type="text" placeholder="Name" />
                        </div>
                        <div>
                            <input type="text" placeholder="Phone Number" />
                        </div>
                        <div>
                            <input type="email" placeholder="Email" />
                        </div>
                        <div>
                            <input type="text" class="message-box" placeholder="Message" />
                        </div>
                        <div class="d-flex ">
                            <button>
                                SEND
                            </button>
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                    <div class="map_container">
                        <div class="map">
                            <div id="googleMap" style="width:100%;height:100%;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- end contact section -->


    <!-- info section -->
    <section class="info_section ">
        <div class="container">
            <h4>
                Get In Touch
            </h4>
            <div class="row">
                <div class="col-lg-10 mx-auto">
                    <div class="info_items">
                        <div class="row">
                            <div class="col-md-4">
                                <a href="">
                                    <div class="item ">
                                        <div class="img-box ">
                                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                                        </div>
                                        <p>
                                            Lorem Ipsum is simply dummy text
                                        </p>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="">
                                    <div class="item ">
                                        <div class="img-box ">
                                            <i class="fa fa-phone" aria-hidden="true"></i>
                                        </div>
                                        <p>
                                            +02 1234567890
                                        </p>
                                    </div>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <a href="">
                                    <div class="item ">
                                        <div class="img-box">
                                            <i class="fa fa-envelope" aria-hidden="true"></i>
                                        </div>
                                        <p>
                                            demo@gmail.com
                                        </p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="social-box">
            <h4>
                Follow Us
            </h4>
            <div class="box">
                <a href="">
                    <i class="fa fa-facebook" aria-hidden="true"></i>
                </a>
                <a href="">
                    <i class="fa fa-twitter" aria-hidden="true"></i>
                </a>
                <a href="">
                    <i class="fa fa-youtube" aria-hidden="true"></i>
                </a>
                <a href="">
                    <i class="fa fa-instagram" aria-hidden="true"></i>
                </a>
            </div>
        </div>
    </section>



    <!-- end info_section -->

    <!-- footer section -->
    <footer class="footer_section">
        <div class="container">
            <p>
                &copy; <span id="displayDateYear"></span> All Rights Reserved By
                <a href="https://html.design/">Free Html Templates</a>
            </p>
        </div>
    </footer>
    <!-- footer section -->

    <script src="{{ asset('assets/js/jquery-3.4.1.min.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
    <script src="{{ asset('assets/js/custom.js') }}"></script>
    <!-- Google Map -->
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
    </script>
    <!-- End Google Map -->


</body>

</html>
