<footer class="footer">
    <div class="text-center">
        Copyright ©  Hostelmanagement 2024
    </div>
</footer>